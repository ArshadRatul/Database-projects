from django.apps import AppConfig


class NumberSectionsOfferedConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'number_sections_offered'
