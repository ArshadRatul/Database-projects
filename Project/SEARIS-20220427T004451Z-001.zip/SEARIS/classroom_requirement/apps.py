from django.apps import AppConfig


class ClassroomRequirementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'classroom_requirement'
