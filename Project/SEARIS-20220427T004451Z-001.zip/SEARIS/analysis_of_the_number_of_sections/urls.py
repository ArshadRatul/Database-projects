from django.urls import views

urlpatterns = [
    path('analysis_of_the_number_of_sections/',views.generate),
]
