from django.apps import AppConfig


class AnalysisOfTheNumberOfSectionsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'analysis_of_the_number_of_sections'
