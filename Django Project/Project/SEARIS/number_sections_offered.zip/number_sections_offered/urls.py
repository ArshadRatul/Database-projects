from django.urls import views

urlpatterns = [
    path('Number_of_section_offered_SETS/',views.generate),
]
